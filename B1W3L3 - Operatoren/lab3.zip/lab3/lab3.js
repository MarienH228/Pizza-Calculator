const GETAL = 6;

// De tafel van GETAL
document.write('<br>1 x ' + GETAL + ' = ' + 1 * GETAL);



